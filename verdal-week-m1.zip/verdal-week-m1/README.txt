Verdal — week ending 06/22/2026. Raw material for the weekly investor update: call transcripts, emails, and a voice memo. Nothing here is marked 'important' — that's your job.
