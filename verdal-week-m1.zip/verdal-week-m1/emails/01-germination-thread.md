From: Priya Raman <priya@germinationcap.com>
To: Maya Lindgren <maya@verdal.farm>
Cc: Theo Okafor <theo@germinationcap.com>, Tomás Vélez <tomas@germinationcap.com>
Subject: Seed round — next steps + timeline
Date: 06/19/2026

Maya,

Good catching up earlier this week. Looping in Theo (he'll run diligence on the ops side) and Tomás from our platform team.

To put structure around the next few weeks: we'd like to get the partnership to a decision before our July offsite, so the working target is to have term-sheet conversations wrapped by early July. That keeps the seed tranche on the timeline we discussed — first close, then the milestone-based portion later. As I mentioned on the call, treat the tranche as runway, not revenue; it shouldn't show up anywhere as top-line.

Two asks from our side:
1. Could you stand up a light data room? Cap table, the last few months of burn, and your current runway view are the priority items.
2. Theo will want ~45 min with you on the robotics/RaaS side — Bartram and Carver in particular, since the autonomy story is what we're underwriting.

Does Tuesday or Wednesday next week work for the diligence call? Mornings ET are easiest for us.

Best,
Priya

Priya Raman
Partner, Germination Capital


--- 

From: Maya Lindgren <maya@verdal.farm>
To: Priya Raman <priya@germinationcap.com>
Cc: Theo Okafor <theo@germinationcap.com>, Tomás Vélez <tomas@germinationcap.com>
Subject: Re: Seed round — next steps + timeline
Date: 06/20/2026

Priya — thanks, and welcome Theo and Tomás.

Early-July works for us. I'll have the data room up by Monday — cap table and burn are easy, and I'll include the current runway view as it stands today (it's tightened a bit since we last modeled it, so I'd rather you see the live number than a stale one).

Wednesday morning is better than Tuesday on my end. Say 9:30 ET? I'll bring Marcus in for the robotics portion — he can walk Theo through where Bartram and Carver are now versus the spring.

Understood on the tranche framing — we won't book it as revenue anywhere, internal or external.

Quick logistics question: do you want the first-close paperwork to run through your counsel or ours? Whichever is faster on your side, we'll match.

Maya


---

From: Priya Raman <priya@germinationcap.com>
To: Maya Lindgren <maya@verdal.farm>
Cc: Theo Okafor <theo@germinationcap.com>, Tomás Vélez <tomas@germinationcap.com>
Subject: Re: Seed round — next steps + timeline
Date: 06/22/2026

Wednesday 9:30 ET is confirmed — calendar invite to follow. Marcus on the robotics half is perfect.

Our counsel can drive the first-close docs; we'll send the template once the diligence call is behind us. No need to over-engineer the data room — the runway view is the thing we'll spend time on, so don't sweat polishing the rest.

Talk Wednesday.

Priya
