From: Bruno Saldana <bruno@harborgreens-dist.com>
To: Maya Lindgren <maya@verdal.farm>
Subject: This week's pickups + a small thank-you
Date: 06/22/2026

Maya,

Quick one before the week closes out. Pickups from South Ward and Ironbound both went smooth — drivers were in and out, pallets were labeled right, nothing bounced back. Your dock crew has gotten fast. Tell them I said so.

Two housekeeping things on my end:

1. We're moving you to net-30 on the off-take invoices starting with this cycle — same as our other standing accounts. Nothing you need to do, just so your books reflect it. The June statements will go out on the new terms.

2. I'd like to lock the pickup window for next month. If we can keep it to Tuesday and Thursday mornings I can hold the same two trucks for you, which keeps everyone's life simpler. Let me know if that still works with your packing schedule.

Also — thank you for the heads-up last week on the volume ramp. Giving me that runway on the forecast let me line up shelf space ahead of time instead of scrambling. Makes me look good to my accounts, which makes me want to keep pushing Verdal product. Appreciate you running it like a partner.

Have a good weekend. Talk early next week on the calendar.

Bruno

Bruno Saldana
Harbor Greens Distribution
