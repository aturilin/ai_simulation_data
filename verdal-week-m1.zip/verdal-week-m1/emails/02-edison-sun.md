From: Edison & Sun Power Co. <no-reply@billing.edisonsun.com>
To: accounts@verdal.farm
Subject: Your Edison & Sun Power Co. statement is ready — Account 4471-082-336
Date: 06/22/2026

This is an automated notice. Please do not reply to this message.

Dear Customer,

Your latest Edison & Sun Power Co. statement is now available. A summary is provided below for your records. The full statement can be viewed or downloaded by signing in to your online account.

------------------------------------------------------------
ACCOUNT SUMMARY
------------------------------------------------------------
Account number:      4471-082-336
Account name:        VERDAL FARM INC
Rate class:          GLP-4 (General Service — Large Power)
Meter number:        ES-77120945 (combined service)

Service addresses on this meter:
  • Verdal South Ward — 215 Lehigh Ave, Newark, NJ 07112
  • Verdal Ironbound — 88 Delancy St, Newark, NJ 07105

(These two service locations are co-located on a single combined
meter. Usage and charges are billed together under this account.)

------------------------------------------------------------
BILLING PERIOD
------------------------------------------------------------
Read dates:          05/19/2026 – 06/18/2026 (30 days)
Statement date:      06/22/2026
Payment due date:    07/13/2026

------------------------------------------------------------
CHARGES
------------------------------------------------------------
Metered usage:                       51,240 kWh
Delivery charges:                    $ 2,113.46
Supply charges:                      $ 3,402.18
Demand charge (peak kW):             $   486.90
State sales & use tax:               $   374.71
                                     -----------
Total amount due:                    $ 6,377.25

------------------------------------------------------------
COMPARE TO LAST PERIOD
------------------------------------------------------------
                          This period      Prior period
Metered usage (kWh):           51,240            42,910
Total amount due ($):        6,377.25          5,108.44

Your current charges are higher than the prior billing period.

------------------------------------------------------------

Payment can be made online, by phone, or by mail. If you are
enrolled in AutoPay, the total amount due will be drafted on the
payment due date and no action is required.

For questions about your statement, billing history, or rate
class, contact Business Customer Service at 1-800-555-0142,
Monday–Friday, 8:00 AM – 6:00 PM ET, or visit your online
account.

Thank you for being an Edison & Sun Power Co. customer.

Edison & Sun Power Co.
Business & Commercial Accounts
P.O. Box 4490, Newark, NJ 07101

This statement notification was sent to accounts@verdal.farm.
Please do not reply to this automated address.
