Call — Bruno (distributor) / Maya Lindgren
06/19/2026, ~15 min

Bruno: Maya, hey. Can you hear me okay? I'm in the van, parked outside the Ironbound dock.
Maya: Loud and clear. How'd the morning pull go?
Bruno: Good, good. Easy load. The crew there has it down now — pallets staged, labeled, ready. We were out in twenty minutes.
Maya: Nice. That used to be an hour.
Bruno: It used to be a mess, is what it used to be. Anyway, I wanted to catch you because I've got good news and I'd rather say it on a call than text it.
Maya: Okay, I'm listening.
Bruno: The Albion strawberries. They are moving. I mean really moving. I've placed everything you've sent me this month and I'm getting calls for more.
Maya: Yeah?
Bruno: Yeah. Two of my specialty accounts came back and asked specifically for "the local berries" — that's how they say it, they don't even use the variety name. They just want the Albion. The pints are gone by Saturday afternoon, every week.
Maya: That's great to hear, honestly. We've put a lot into that crop.
Bruno: And it shows. The eating quality is there, the look is there — these things photograph well, the chefs love that. One of the restaurant guys in the Ironbound put them on the menu as a named item. "Verdal strawberries." I saw it myself.
Maya: Ha. Okay, that's a first.
Bruno: It's not nothing. That's a premium placement. People pay for that berry. So the revenue side on Albion — it's up, it's up nicely, and I don't see it slowing down. Summer demand's only climbing.
Maya: Good. I'll take it. We can use a clean win this week.
Bruno: You're getting one. Now — logistics. If this keeps up I want to talk about the pickup schedule. Right now I'm doing the one run, the South Ward pull plus the Ironbound dock on the same loop. If volume on the berries grows I might need a second window later in the week so I'm not sitting on inventory.
Maya: Makes sense. What are you thinking, a Thursday?
Bruno: Maybe a Thursday, maybe a Friday morning. I don't want to commit yet, I just want it on your radar so it's not a surprise when I ask. The cold chain on the strawberries is tighter than the lettuce — I can hold butterhead a day, the berries I'd rather not.
Maya: Understood. Let me look at what the harvest cadence is on the Albion beds and I'll come back to you with what we can actually pick to. I don't want to promise you a second run and then not have the fruit ready.
Bruno: That's fair. That's all I ask. The lettuce, by the way — butterhead, the oakleaf — that's steady. No complaints, no surprises. Moves fine, just doesn't fly off the shelf the way the berries do. Bread and butter.
Maya: That's kind of what it's there for.
Bruno: Right. The herbs too — basil, the cilantro — small steady orders, the same accounts every week. It's the strawberries that are the story right now. That's the one everybody's excited about.
Maya: I hear you. Okay. Anything on your end I should know — packaging, any issues at the dock?
Bruno: No issues. The clamshells are good. One thing, minor — a couple of the berry labels were peeling a little in the cooler, the adhesive. Probably the humidity in the box. Not a problem, the accounts didn't say anything, I just noticed it. Worth flagging to whoever does the labels.
Maya: I'll pass it along. Thanks for catching it.
Bruno: Of course. We're partners, I want this to work. And look — you should feel good about the Albion. It's carrying a real shine for you out there in the market. People in the Ironbound are starting to know the name.
Maya: That means a lot, Bruno. Genuinely.
Bruno: I mean it. So — I'll keep placing what you send, you figure out the harvest, and we'll talk second pickup once you've got the numbers on the beds.
Maya: Deal. Drive safe.
Bruno: Always. Talk soon, Maya.
Maya: Bye, Bruno.
