Call — Verdal Yield subscriber check-in
Date: 06/19/2026
Participants: Maya Lindgren (Verdal); Devon Pryce (GreenRow Farms — Verdal Yield subscriber)

Maya: Hey Devon, can you hear me okay?

Devon: Loud and clear. Thanks for jumping on, I know it's a Friday.

Maya: Of course. So — wanted to check in now that you've had the margin-by-crop view for a couple weeks. How's it landing?

Devon: Honestly? It's the first thing I open in the morning now. Used to be I'd export everything into a spreadsheet on Sundays and squint at it. Now I just pull up Yield and it's already broken out by crop, by bed. Saved me the whole Sunday ritual.

Maya: That's great to hear. And you're running it across both your sites?

Devon: Both sites, yeah. We've got the Yield dashboard up on the wall in the packhouse now. The team actually looks at it. That part surprised me — I figured it'd be a me-only tool, but the leads are using it to decide what to cut first.

Maya: Love that. That's exactly the use we were hoping for.

Devon: Can I ask — how many of us are on this now? Feels like it went from beta to real product pretty fast.

Maya: Yeah, it's moving. As of this week Verdal Yield is live on twelve partner farms. You were, what, number five or six?

Devon: Five. I'll take the early-adopter badge.

Maya: Earned it. Twelve farms, and the margin-by-crop view is the thing people are sticking around for, so your feedback fed straight into that.

Devon: Good. It shows. One thing — and this is minor — the bed-level filter is a little buried. Took me a minute to find it the first time.

Maya: Noted. That's an easy fix, I'll flag it to the team. Anything on the data side feel off? Numbers matching what you see on the floor?

Devon: Matching. That was my first worry, that it'd be garbage-in. But it's tracking. I cross-checked a couple beds by hand the first week and it lined up.

Maya: Perfect. That's the part I care most about — that you trust the number.

Devon: I do. Look, for what it's worth, this is the first tool I've paid for in this space that I'd actually be annoyed to lose. So. Keep it running.

Maya: That's the best review I'll get all week. Thank you, Devon. I'll get that filter thing sorted and I'll check back in a few weeks.

Devon: Sounds good. Have a good weekend.

Maya: You too.
