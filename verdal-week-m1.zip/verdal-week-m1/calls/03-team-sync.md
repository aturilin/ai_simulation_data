Team sync — weekly ops/product
06/19/2026, 9:32 AM
Present: Maya, Sara, Marcus, Dani, Linnea

Maya: Okay, we're all here. Let's keep it tight, I've got the Germination call right after. Sara, you want to start?

Sara: Sure. Big one first — the autonomous collection cycle is live. Bartram and Carver are running the full cycle end to end now. No operator in the loop, no babysitting. They pick the trays, run the collection pass, log it, reset. Start to finish on their own.

Marcus: On both?

Sara: Both. Bartram's been clean since Tuesday, Carver came online Wednesday after we flashed the new firmware. They've done a couple of full overnight passes with nobody on the floor.

Maya: That's the thing we've been chasing for like four months.

Sara: Yeah. It's done. It works.

Dani: Confirmed from my side, the logs are coming through clean. Cycle completes, hands off to the dashboard, no manual stitch.

Maya: Good. That's the headline. Marcus, Yield?

Marcus: Yeah, we shipped the Yield release. The margin-by-crop view is out — subscribers can finally see per-crop instead of just the blended number. That was the most requested thing in the feedback.

Dani: It's behind the same login, no migration needed, it just shows up.

Marcus: Right. People log in, the new view's there. We pushed it Thursday afternoon, nothing on fire so far.

Maya: Anyone complaining?

Marcus: Nope. Couple of "oh nice" replies, that's it. Quiet launch, which is what we wanted.

Maya: Okay. Good week. Anything on the floor I should know? Linnea?

Linnea: Mostly normal. One thing — Burbank's down. The harvest unit at South Ward. Threw a fault on the actuator arm Monday and we can't get it back up, we're waiting on a part.

Maya: How long?

Linnea: Few days. Vendor said the replacement ships, we're looking at probably middle of next week before it's back.

Maya: And in the meantime?

Linnea: We slipped the oakleaf harvest on that block. It was Burbank's row, no backup unit free, so it just sat. We'll catch it on the next cycle but that planting's off schedule now.

Marcus: Can Carver pick it up?

Linnea: Different bed config, no. It's fine, it's one block, it's just late.

Maya: Okay. Flag it when the part lands so we know it's back.

Linnea: Will do.

Maya: Dani, anything else on data?

Dani: Nothing big. The dashboard's stable, the new Yield view's reporting fine. I'll keep an eye on the collection-cycle logs over the weekend now that it's unattended, but it's been boring, which is good.

Maya: Boring is great. Sara, anything else?

Sara: No. Just — Bartram and Carver running themselves is a real milestone, I don't want it to get lost in the standup. That's months of work.

Maya: It's not getting lost. That's going in the update. Okay, that's me, I've got to jump. Thanks everyone. Good week.

Marcus: Later.

Dani: Bye.
