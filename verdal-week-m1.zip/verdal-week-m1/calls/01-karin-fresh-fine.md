# Call — Karin (Fresh & Fine Markets) / Maya Lindgren

Date: 06/22/2026
Participants: Karin (Fresh & Fine Markets, produce buyer), Maya Lindgren (Verdal)

---

Karin: Maya, hi — got two minutes? I'm between vendor calls, you know how Mondays are.

Maya: Hey Karin, yeah, two minutes is perfect. How's the floor looking?

Karin: That's exactly why I'm calling. The pilot's flying. I mean it. The greens are moving faster than anything in that aisle, the herbs right behind them, and the produce team keeps asking me when we get more.

Maya: That's great to hear.

Karin: It's better than great. Customers are coming back for it specifically — we've had people ask the floor staff by name for your butterhead. That doesn't happen with a new SKU. Usually I'm fighting to keep a pilot on the shelf for the full window. With yours I'm fighting to keep it stocked.

Maya: Honestly that's the best problem you could hand me.

Karin: Right? So here's where I'm going with this. I want to expand the shelf space. The little pilot footprint we gave you — I want to take it bigger. I'm thinking we pull it out of the trial endcap and give it a proper run in the main produce set, more facings, the works.

Maya: We'd love that. We've got the supply to back a bigger footprint, so the timing's good on our end too.

Karin: Good. Because I don't want to lose the momentum while it's hot. The longer it sits in the pilot corner the more I'm leaving on the table.

Maya: Agreed. So what do you need from me to move it forward?

Karin: To take it up the chain — I have to make the case to my category lead, and she runs on data, not on my enthusiasm. So: send me the pilot numbers. The sell-through, the repeat-buy, whatever you've got from the run so far. Put it in front of me and I'll build the expansion case around it.

Maya: I can do that. I'll pull the pilot performance together and get it over to you.

Karin: Perfect. The cleaner the numbers, the faster I can move this. If they look anything like what I'm seeing on the floor, this is an easy yes for her.

Maya: I'll make them clean. When do you need them by?

Karin: Soon as you can. This week ideally — I've got the category review coming up and I'd love to walk in with you already on the table.

Maya: You'll have them this week.

Karin: Love it. Okay, my next call's lighting up. Send those over and let's get you more shelf. Talk soon, Maya.

Maya: Thanks Karin — talk soon.
