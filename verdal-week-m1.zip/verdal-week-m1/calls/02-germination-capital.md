Call — Germination Capital check-in
Date: 06/18/2026, 4:00 PM ET
Participants: Maya Lindgren (Verdal), Theo Okafor (Germination Capital, lead)

---

Theo: Maya, hey. Can you hear me okay?

Maya: Yeah, loud and clear. Thanks for making time, I know it's late on your end.

Theo: No, it's good. I had it down for a quick one anyway. So — how are you doing? Not the deck version. Actually.

Maya: Honestly? Busy in a good way. Heads down. The team's been shipping, I've been out talking to the people who actually use the stuff. So, energized, tired, the usual.

Theo: That's the right kind of tired. Okay. I want to keep this loose, but there are two or three things I want to make sure we touch. Let me start with the boring one so it's not hanging over us — where are you against the milestones we wrote into the term sheet?

Maya: Sure. So the way you and I framed it back then, the second tranche releases against operational milestones, not a revenue number. Which I still think was the right call.

Theo: It was. I want to be clear about that on the record, by the way, because it comes up internally. The seed is structured in tranches, the next one is milestone-gated. It is not tied to top-line. Nobody on my side is sitting here waiting for you to post revenue to unlock it. That's not what this money is.

Maya: Right. And that distinction matters to me, because it lets me build the thing in the right order instead of chasing a number to hit a date.

Theo: Exactly. So — the milestones. Walk me through it at the level you're comfortable with. Are we on track?

Maya: We're on track. I'm not going to walk you through every line item on this call, I'd rather show you properly next week with the team in the room. But the operational targets we set — the ones that gate the tranche — we've hit the substance of them this quarter. There's a couple of edges I want to tighten before I say "done, sign here," but the core is there.

Theo: Okay. That's roughly where I expected you to be, which is reassuring. When you say a couple of edges — are those edges that move the timeline, or edges that are just you being a perfectionist?

Maya: Bit of both, if I'm honest. Mostly the second one. None of it changes the milestone story.

Theo: Good. Then I'll stop poking at it. Let me ask the thing I actually called about. How's runway? Real number, not the rounded one.

Maya: Runway's shorter than when we last spoke. That's just the state of it.

Theo: Shorter how — like, the burn stepped up, or you're just further down the same slope?

Maya: Further down the same slope, mostly. We're spending roughly what I told you we'd spend. But there's no revenue cushion underneath it to slow the clock, so every month it just ticks down. There's no surprise in it. It's just — the number is what it is now, and it's smaller than it was.

Theo: Okay. And you're telling me that flatly, which I appreciate. So let me make sure I'm reading you right. You're not calling to tell me there's a hole. You're calling because the runway being what it is means we should start the next conversation sooner rather than later.

Maya: That's exactly it. I don't want to be the founder who shows up with six weeks of cash acting surprised. The runway is tightening, that's the fact, and the responsible version of me starts the raise conversation now — with room — instead of cornered. So yes. That's why I wanted you on the phone this week and not in two months.

Theo: That's the right instinct and it's why I like working with you. I'd much rather have this talk with daylight than under a deadline. Have you put a shape to what the next round looks like yet — size, who leads, the framing?

Maya: I have thoughts. They're still mine and a notebook at this point — I'm not going to float you a number on a Thursday call I haven't slept on. Let me bring you something deliberate rather than something off the cuff.

Theo: Fair. I'd actually rather you do that. Half-formed numbers anchor people in ways that are hard to walk back, so — bring me the version you've actually thought through.

Maya: That's the plan.

Theo: Okay. On mechanics, while we're here, so you're not guessing: when you do come back to us, the cleanest path is probably we look at the milestone tranche and the next raise as two separate conversations, not one bundled thing. The tranche releases on what we already agreed — that's mechanical, that's almost administrative once you say the milestones are met. The raise is its own animal. Don't let them get tangled.

Maya: That's helpful, actually. I'd been holding them in the same mental bucket.

Theo: Don't. The tranche is money you've effectively already earned by hitting the marks — it's gated, but it's not a negotiation. The raise is the negotiation. Keep them clean and you'll have a much easier time.

Maya: Noted. That genuinely simplifies how I think about the next few weeks.

Theo: Good. Then here's where I'd land it for today. One — milestones, you sound on track, show me properly next week. Two — runway's tighter, understood, no alarm bells, and I hear you that it's the reason to move now. Three — you go away and bring me a deliberate shape for the round, and we don't improvise it on a phone call. Does that match your version of this conversation?

Maya: It does. That's the conversation.

Theo: Then we're aligned. Send me a time for the full walkthrough with the team. And Maya — calling early instead of late is the correct move. Keep doing that.

Maya: Will do. Thanks, Theo. Talk next week.

Theo: Talk next week. Bye.
